@extends('layouts.admin-main')

@section('title', 'Profile')

@section('content')

<h2>User List</h2>
</br>
<div id="js_user_render"></div>
@endsection