@extends('layouts.main')

@section('title', 'Login')

@section('content')
	<h2>Welcome to ProfileBook. Please Joined Us..</h2>
@endsection
​