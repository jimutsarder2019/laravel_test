

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
	<form id="signup" method="POST" action="/login">
		<div class="header-area">
			<h3>Login</h3>  
		</div>
		<div class="sep"></div>

		<div class="inputs">
			<?php echo e(csrf_field()); ?>


			<div class="form-group">
				<label for="email">Email:</label>
				<input type="email" class="form-control" id="email" name="email">
			</div>
			<?php if($errors->has('email')): ?>
			    <div class="error"><?php echo e($errors->first('email')); ?></div>
			    </br>
		    <?php endif; ?>
	 
			<div class="form-group">
				<label for="password">Password:</label>
				<input type="password" class="form-control" id="password" name="password">
			</div>	
			<?php if($errors->has('password')): ?>
			    <div class="error"><?php echo e($errors->first('password')); ?></div>
			    </br>
		    <?php endif; ?>
			
			<?php if($errors->has('message')): ?>
				<div class="error"><?php echo e($errors->first('message')); ?></div>
			<?php endif; ?>
	 
			<div class="form-group">
				<button id="submit" style="cursor:pointer" type="submit" class="btn btn-primary">Login</button>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
​
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\blog\resources\views/login/create.blade.php ENDPATH**/ ?>