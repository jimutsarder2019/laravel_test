

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

<h2>User Dashboard</h2>
</br>
<table class="w3-table-all" id="customers">
	<tr>
	   <th class="text-center">ID</th>
	   <th class="text-center">Name</th>
	   <th class="text-center">Email</th>
	   <th class="text-center">Action</th>
	</tr>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr class="js_user_row_<?php echo $user->id; ?>">
			<td class="text-center"><strong><?php echo $user->id; ?></strong></td>
			<td class="text-center"><strong id="js_name_<?php echo $user->id; ?>"><?php echo $user->name; ?></strong></td>
			<td class="text-center"><strong id="js_email_<?php echo $user->id; ?>"><?php echo $user->email; ?></strong></td>
			<td class="text-center">
				<div class="row">
				    <div class="col-md-4">
						<a class="js_user_view" data-id="<?php echo $user->id; ?>" href="javascript:void(0)">View</a>
					</div>
					<div class="col-md-4">
						<a class="js_user_update_modal" data-id="<?php echo $user->id; ?>" href="javascript:void(0)">Update</a>
					</div>
					<div class="col-md-4">
						<a class="js_user_delete" data-id="<?php echo $user->id; ?>" href="javascript:void(0)">Delete</a>
					</div>
				</div>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div id="demo"></div>

<!-- Modal -->
  <div class="modal fade js_user_view_modal" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body js_user_modal_body">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\blog\resources\views/admindashboard.blade.php ENDPATH**/ ?>