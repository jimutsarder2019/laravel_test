

<?php $__env->startSection('title', 'Registration'); ?>

<?php $__env->startSection('content'); ?>
	<form id="signup" method="POST" action="/register">
		<div class="header-area">
			<h3>Sign Up</h3> 
			<p>You want to fill out this form</p>    
		</div>
		<div class="sep"></div>
		
		<?php if(@$message): ?>
			<div class="success"><?php echo e(@$message); ?></div>
		<?php endif; ?>

		<div class="inputs">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label for="name">Name:</label>
				<input type="text" class="form-control" id="name" name="name">
			</div>
			<?php if($errors->has('name')): ?>
			    <div class="error"><?php echo e($errors->first('name')); ?></div>
		   		</br>
		    <?php endif; ?>

			<div class="form-group">
				<label for="email">Email:</label>
				<input type="email" class="form-control" id="email" name="email">
			</div>
			<?php if($errors->has('email')): ?>
			    <div class="error"><?php echo e($errors->first('email')); ?></div>
			    </br>
		    <?php endif; ?>
	 
			<div class="form-group">
				<label for="password">Password:</label>
				<input type="password" class="form-control" id="password" name="password">
			</div>	
			<?php if($errors->has('password')): ?>
			    <div class="error"><?php echo e($errors->first('password')); ?></div>
			    </br>
		    <?php endif; ?>
	 
			<div class="form-group">
				<label for="password_confirmation">Password Confirmation:</label>
				<input type="password" class="form-control" id="password_confirmation"
					   name="password_confirmation">
			</div>
	 
			<div class="form-group">
				<button id="submit" style="cursor:pointer" type="submit" class="btn btn-primary">Sign Up</button>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
​
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\profile\resources\views/registration/create.blade.php ENDPATH**/ ?>