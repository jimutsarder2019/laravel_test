<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
	<h2>Welcome to ProfileBook. Please Joined Us..</h2>
<?php $__env->stopSection(); ?>
​
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\profile\resources\views/home.blade.php ENDPATH**/ ?>